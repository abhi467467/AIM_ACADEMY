import React from 'react';
import { Link } from 'react-router-dom';
import { VideoIcon, BookOpenIcon, FileTextIcon, BellIcon, CalendarIcon, BarChartIcon } from 'lucide-react';
const StudentDashboard = () => {
  // Mock data for student dashboard
  const upcomingLectures = [{
    id: 1,
    subject: 'Physics',
    topic: 'Quantum Mechanics',
    time: 'Today, 3:00 PM'
  }, {
    id: 2,
    subject: 'Mathematics',
    topic: 'Calculus',
    time: 'Tomorrow, 10:00 AM'
  }];
  const recentHomework = [{
    id: 1,
    subject: 'Chemistry',
    title: 'Organic Compounds',
    dueDate: 'Tomorrow'
  }, {
    id: 2,
    subject: 'English',
    title: 'Essay Writing',
    dueDate: '3 days left'
  }];
  const recentNotices = [{
    id: 1,
    title: 'Holiday Announcement',
    date: 'Today'
  }, {
    id: 2,
    title: 'Exam Schedule Updated',
    date: 'Yesterday'
  }];
  const recentTestScores = [{
    id: 1,
    subject: 'Physics',
    score: 85,
    total: 100,
    date: 'Last week'
  }, {
    id: 2,
    subject: 'Mathematics',
    score: 92,
    total: 100,
    date: '2 weeks ago'
  }];
  return <div>
      <h1 className="text-2xl font-bold mb-6">Student Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Upcoming Lectures */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Upcoming Lectures</h2>
            <Link to="/live-lectures" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {upcomingLectures.map(lecture => <div key={lecture.id} className="flex items-start">
                <div className="bg-indigo-100 p-2 rounded-md mr-3">
                  <VideoIcon className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-medium">
                    {lecture.subject}: {lecture.topic}
                  </h3>
                  <p className="text-sm text-gray-500">{lecture.time}</p>
                </div>
              </div>)}
          </div>
        </div>
        {/* Recent Homework */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Homework</h2>
            <Link to="/homework" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {recentHomework.map(homework => <div key={homework.id} className="flex items-start">
                <div className="bg-orange-100 p-2 rounded-md mr-3">
                  <FileTextIcon className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-medium">
                    {homework.subject}: {homework.title}
                  </h3>
                  <p className="text-sm text-gray-500">
                    Due: {homework.dueDate}
                  </p>
                </div>
              </div>)}
          </div>
        </div>
        {/* Recent Notices */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Notices</h2>
            <Link to="/notices" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {recentNotices.map(notice => <div key={notice.id} className="flex items-start">
                <div className="bg-red-100 p-2 rounded-md mr-3">
                  <BellIcon className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <h3 className="font-medium">{notice.title}</h3>
                  <p className="text-sm text-gray-500">Posted: {notice.date}</p>
                </div>
              </div>)}
          </div>
        </div>
        {/* Recent Test Scores */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Test Results</h2>
            <Link to="/test-results" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {recentTestScores.map(test => <div key={test.id} className="flex items-start">
                <div className="bg-green-100 p-2 rounded-md mr-3">
                  <BarChartIcon className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">{test.subject}</h3>
                  <p className="text-sm text-gray-500">
                    Score: {test.score}/{test.total} (
                    {Math.round(test.score / test.total * 100)}%)
                  </p>
                  <p className="text-xs text-gray-400">{test.date}</p>
                </div>
              </div>)}
          </div>
        </div>
        {/* Study Materials */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Study Materials</h2>
            <Link to="/study-materials" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="p-4 border border-dashed border-gray-300 rounded-md text-center">
            <BookOpenIcon className="w-8 h-8 text-indigo-600 mx-auto mb-2" />
            <p className="text-gray-600">
              Access all your study materials and resources
            </p>
            <Link to="/study-materials" className="mt-3 inline-block px-4 py-2 bg-indigo-600 text-white text-sm rounded-md hover:bg-indigo-700">
              Browse Materials
            </Link>
          </div>
        </div>
        {/* Attendance Overview */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Attendance Overview</h2>
            <Link to="/attendance" className="text-indigo-600 text-sm hover:underline">
              View details
            </Link>
          </div>
          <div className="flex items-center justify-center">
            <div className="w-32 h-32 relative">
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e5e7eb" strokeWidth="3" />
                <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#4f46e5" strokeWidth="3" strokeDasharray="85, 100" strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-3xl font-bold text-gray-800">85%</span>
                <span className="text-sm text-gray-500">Present</span>
              </div>
            </div>
          </div>
          <div className="flex justify-between text-sm mt-4">
            <div className="text-center">
              <div className="font-medium">42</div>
              <div className="text-gray-500">Present</div>
            </div>
            <div className="text-center">
              <div className="font-medium">7</div>
              <div className="text-gray-500">Absent</div>
            </div>
            <div className="text-center">
              <div className="font-medium">5</div>
              <div className="text-gray-500">Holidays</div>
            </div>
          </div>
        </div>
      </div>
    </div>;
};
export default StudentDashboard;