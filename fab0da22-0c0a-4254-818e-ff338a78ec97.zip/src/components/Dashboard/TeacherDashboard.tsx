import React from 'react';
import { Link } from 'react-router-dom';
import { UsersIcon, VideoIcon, FileTextIcon, BellIcon, CalendarIcon, BarChartIcon, PlusIcon, ClockIcon, CheckIcon } from 'lucide-react';
const TeacherDashboard = () => {
  // Mock data for teacher dashboard
  const upcomingLectures = [{
    id: 1,
    subject: 'Physics',
    topic: 'Quantum Mechanics',
    time: 'Today, 3:00 PM',
    students: 28
  }, {
    id: 2,
    subject: 'Mathematics',
    topic: 'Calculus',
    time: 'Tomorrow, 10:00 AM',
    students: 32
  }];
  const pendingHomework = [{
    id: 1,
    subject: 'Chemistry',
    title: 'Organic Compounds',
    submissions: 18,
    total: 25
  }, {
    id: 2,
    subject: 'English',
    title: 'Essay Writing',
    submissions: 22,
    total: 30
  }];
  const classPerformance = [{
    id: 1,
    subject: 'Physics',
    avgScore: 78,
    highest: 95
  }, {
    id: 2,
    subject: 'Mathematics',
    avgScore: 82,
    highest: 98
  }, {
    id: 3,
    subject: 'Chemistry',
    avgScore: 75,
    highest: 92
  }];
  const recentActivities = [{
    id: 1,
    action: 'Lecture completed',
    subject: 'Physics',
    time: '2 hours ago'
  }, {
    id: 2,
    action: 'Materials uploaded',
    subject: 'Chemistry',
    time: 'Yesterday'
  }, {
    id: 3,
    action: 'Test grades updated',
    subject: 'Mathematics',
    time: '2 days ago'
  }];
  return <div>
      <h1 className="text-2xl font-bold mb-6">Teacher Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center">
            <div className="bg-indigo-100 p-3 rounded-md">
              <UsersIcon className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="ml-4">
              <h2 className="text-gray-500 text-sm">Total Students</h2>
              <p className="text-2xl font-bold">124</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-md">
              <VideoIcon className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <h2 className="text-gray-500 text-sm">Lectures Completed</h2>
              <p className="text-2xl font-bold">38</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center">
            <div className="bg-orange-100 p-3 rounded-md">
              <FileTextIcon className="w-6 h-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <h2 className="text-gray-500 text-sm">Materials Shared</h2>
              <p className="text-2xl font-bold">56</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center">
            <div className="bg-red-100 p-3 rounded-md">
              <BarChartIcon className="w-6 h-6 text-red-600" />
            </div>
            <div className="ml-4">
              <h2 className="text-gray-500 text-sm">Tests Conducted</h2>
              <p className="text-2xl font-bold">12</p>
            </div>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Upcoming Lectures */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Upcoming Lectures</h2>
            <Link to="/live-lectures" className="text-indigo-600 text-sm hover:underline">
              Manage
            </Link>
          </div>
          <div className="space-y-4">
            {upcomingLectures.map(lecture => <div key={lecture.id} className="p-3 border border-gray-200 rounded-md">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">
                      {lecture.subject}: {lecture.topic}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <ClockIcon className="w-4 h-4 mr-1" /> {lecture.time}
                    </div>
                  </div>
                  <div className="bg-indigo-100 py-1 px-2 rounded text-xs text-indigo-800">
                    {lecture.students} students
                  </div>
                </div>
              </div>)}
            <Link to="/live-lectures" className="flex items-center justify-center py-2 border border-dashed border-gray-300 rounded-md text-indigo-600 hover:bg-indigo-50">
              <PlusIcon className="w-4 h-4 mr-1" /> Schedule New Lecture
            </Link>
          </div>
        </div>
        {/* Homework to Review */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Homework to Review</h2>
            <Link to="/homework" className="text-indigo-600 text-sm hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {pendingHomework.map(homework => <div key={homework.id} className="p-3 border border-gray-200 rounded-md">
                <div>
                  <h3 className="font-medium">
                    {homework.subject}: {homework.title}
                  </h3>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-sm text-gray-500">
                      {homework.submissions}/{homework.total} submissions
                    </div>
                    <Link to="/homework" className="text-xs bg-orange-100 text-orange-800 py-1 px-2 rounded">
                      Review
                    </Link>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                    <div className="bg-orange-500 h-1.5 rounded-full" style={{
                  width: `${homework.submissions / homework.total * 100}%`
                }}></div>
                  </div>
                </div>
              </div>)}
            <Link to="/homework" className="flex items-center justify-center py-2 border border-dashed border-gray-300 rounded-md text-indigo-600 hover:bg-indigo-50">
              <PlusIcon className="w-4 h-4 mr-1" /> Assign New Homework
            </Link>
          </div>
        </div>
        {/* Class Performance */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Class Performance</h2>
            <Link to="/test-results" className="text-indigo-600 text-sm hover:underline">
              Details
            </Link>
          </div>
          <div className="space-y-4">
            {classPerformance.map(subject => <div key={subject.id} className="p-3 border border-gray-200 rounded-md">
                <div>
                  <div className="flex justify-between">
                    <h3 className="font-medium">{subject.subject}</h3>
                    <span className="text-sm font-medium">
                      Avg: {subject.avgScore}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                    <div className="bg-green-500 h-1.5 rounded-full" style={{
                  width: `${subject.avgScore}%`
                }}></div>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Highest score: {subject.highest}%
                  </div>
                </div>
              </div>)}
            <Link to="/test-results" className="flex items-center justify-center py-2 border border-dashed border-gray-300 rounded-md text-indigo-600 hover:bg-indigo-50">
              <PlusIcon className="w-4 h-4 mr-1" /> Upload New Test Results
            </Link>
          </div>
        </div>
        {/* Recent Activities */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Activities</h2>
          </div>
          <div className="relative">
            <div className="absolute top-0 bottom-0 left-4 w-0.5 bg-gray-200"></div>
            <div className="space-y-6 relative">
              {recentActivities.map(activity => <div key={activity.id} className="flex">
                  <div className="flex-shrink-0 bg-white">
                    <div className="h-8 w-8 rounded-full border-2 border-indigo-500 bg-white flex items-center justify-center z-10 relative">
                      <CheckIcon className="h-4 w-4 text-indigo-500" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <div className="font-medium">{activity.action}</div>
                    <div className="text-sm text-gray-500">
                      {activity.subject}
                    </div>
                    <div className="text-xs text-gray-400">{activity.time}</div>
                  </div>
                </div>)}
            </div>
          </div>
        </div>
        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Quick Actions</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Link to="/live-lectures" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <VideoIcon className="w-6 h-6 text-indigo-600 mb-2" />
              <span className="text-sm">Schedule Lecture</span>
            </Link>
            <Link to="/study-materials" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <FileTextIcon className="w-6 h-6 text-orange-600 mb-2" />
              <span className="text-sm">Upload Material</span>
            </Link>
            <Link to="/homework" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <CheckIcon className="w-6 h-6 text-green-600 mb-2" />
              <span className="text-sm">Check Homework</span>
            </Link>
            <Link to="/notices" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <BellIcon className="w-6 h-6 text-red-600 mb-2" />
              <span className="text-sm">Post Notice</span>
            </Link>
            <Link to="/attendance" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <CalendarIcon className="w-6 h-6 text-purple-600 mb-2" />
              <span className="text-sm">Mark Attendance</span>
            </Link>
            <Link to="/test-results" className="p-3 border border-gray-200 rounded-md hover:bg-gray-50 flex flex-col items-center justify-center text-center">
              <BarChartIcon className="w-6 h-6 text-blue-600 mb-2" />
              <span className="text-sm">Update Results</span>
            </Link>
          </div>
        </div>
        {/* Notices */}
        <div className="bg-white rounded-lg shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Notice Board</h2>
            <Link to="/notices" className="text-indigo-600 text-sm hover:underline">
              Manage
            </Link>
          </div>
          <div className="space-y-3">
            <div className="p-3 bg-red-50 border border-red-100 rounded-md">
              <h3 className="font-medium text-red-800">Holiday Announcement</h3>
              <p className="text-sm text-red-700 mt-1">
                Institute will remain closed on 25th for annual function.
              </p>
              <div className="text-xs text-red-500 mt-1">Posted today</div>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-100 rounded-md">
              <h3 className="font-medium text-blue-800">
                Exam Schedule Updated
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                Mid-term exam schedule has been updated.
              </p>
              <div className="text-xs text-blue-500 mt-1">Posted yesterday</div>
            </div>
            <Link to="/notices" className="flex items-center justify-center py-2 border border-dashed border-gray-300 rounded-md text-indigo-600 hover:bg-indigo-50">
              <PlusIcon className="w-4 h-4 mr-1" /> Post New Notice
            </Link>
          </div>
        </div>
      </div>
    </div>;
};
export default TeacherDashboard;