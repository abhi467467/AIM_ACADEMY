import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserIcon, BookOpenIcon, LockIcon } from 'lucide-react';
const LoginPage = ({
  onLogin
}) => {
  const [role, setRole] = useState('student');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const handleSubmit = e => {
    e.preventDefault();
    // Simple validation
    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }
    // Mock authentication - in a real app, this would call an API
    if (username && password) {
      onLogin({
        id: '123',
        name: role === 'teacher' ? 'Dr. Smith' : 'John Doe',
        role: role,
        username: username
      });
      navigate('/');
    } else {
      setError('Invalid credentials');
    }
  };
  return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl overflow-hidden max-w-md w-full">
        <div className="bg-indigo-600 p-6 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white mb-4">
            <BookOpenIcon className="w-8 h-8 text-indigo-600" />
          </div>
          <h1 className="text-2xl font-bold text-white">
            Coaching Institute Portal
          </h1>
          <p className="text-indigo-200 mt-1">
            Sign in to access your dashboard
          </p>
        </div>
        <div className="p-6">
          <div className="flex rounded-md overflow-hidden mb-6">
            <button className={`flex-1 py-2 text-center ${role === 'student' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setRole('student')}>
              Student
            </button>
            <button className={`flex-1 py-2 text-center ${role === 'teacher' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setRole('teacher')}>
              Teacher
            </button>
          </div>
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm">
              {error}
            </div>}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder={role === 'student' ? 'Student ID' : 'Teacher ID'} />
              </div>
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <LockIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Enter your password" />
              </div>
            </div>
            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded-md transition duration-200 font-medium">
              Login as {role === 'student' ? 'Student' : 'Teacher'}
            </button>
          </form>
          <div className="mt-4 text-center text-sm text-gray-600">
            <a href="#" className="text-indigo-600 hover:text-indigo-800">
              Forgot password?
            </a>
          </div>
        </div>
      </div>
    </div>;
};
export default LoginPage;