import React, { useState } from 'react';
import { BellIcon, PlusIcon, XIcon, CheckIcon, CalendarIcon, SearchIcon, TagIcon, TrashIcon } from 'lucide-react';
const Notices = ({
  userRole
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newNotice, setNewNotice] = useState({
    title: '',
    category: 'general',
    content: '',
    pinned: false
  });
  // Mock data
  const categories = [{
    id: 'all',
    name: 'All Notices'
  }, {
    id: 'general',
    name: 'General'
  }, {
    id: 'exam',
    name: 'Exams'
  }, {
    id: 'event',
    name: 'Events'
  }, {
    id: 'holiday',
    name: 'Holidays'
  }];
  const notices = [{
    id: 1,
    title: 'Mid-Term Examination Schedule',
    category: 'exam',
    content: 'The mid-term examinations will be conducted from 15th September to 25th September 2023. The detailed schedule is attached.',
    date: '2023-08-01',
    author: 'Principal',
    pinned: true
  }, {
    id: 2,
    title: 'Annual Function Preparation',
    category: 'event',
    content: 'All students are requested to participate in the annual function preparations. Rehearsals will start from next week.',
    date: '2023-08-05',
    author: 'Cultural Committee'
  }, {
    id: 3,
    title: 'Holiday Announcement',
    category: 'holiday',
    content: 'The institute will remain closed on 15th August for Independence Day celebrations.',
    date: '2023-08-10',
    author: 'Administration'
  }, {
    id: 4,
    title: 'New Books in Library',
    category: 'general',
    content: 'New reference books for all subjects have been added to the library. Students can check them out during library hours.',
    date: '2023-08-12',
    author: 'Librarian'
  }];
  const filteredNotices = notices.filter(notice => {
    const matchesCategory = activeCategory === 'all' || notice.category === activeCategory;
    const matchesSearch = notice.title.toLowerCase().includes(searchQuery.toLowerCase()) || notice.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });
  // Sort: pinned notices first, then by date (newest first)
  const sortedNotices = [...filteredNotices].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return new Date(b.date) - new Date(a.date);
  });
  const handleAddNotice = e => {
    e.preventDefault();
    // In a real app, this would send data to the backend
    console.log('Adding notice:', newNotice);
    setShowAddModal(false);
    // Reset form
    setNewNotice({
      title: '',
      category: 'general',
      content: '',
      pinned: false
    });
  };
  const getCategoryColor = category => {
    switch (category) {
      case 'general':
        return 'bg-gray-100 text-gray-800';
      case 'exam':
        return 'bg-red-100 text-red-800';
      case 'event':
        return 'bg-green-100 text-green-800';
      case 'holiday':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  const getCategoryName = categoryId => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : categoryId;
  };
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Notice Board</h1>
        {userRole === 'teacher' && <button onClick={() => setShowAddModal(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" /> Add Notice
          </button>}
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex overflow-x-auto pb-2 md:pb-0 scrollbar-hide space-x-2">
              {categories.map(category => <button key={category.id} className={`px-4 py-2 rounded-md whitespace-nowrap ${activeCategory === category.id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`} onClick={() => setActiveCategory(category.id)}>
                  {category.name}
                </button>)}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" placeholder="Search notices..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10 w-full md:w-64 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
          </div>
        </div>
        <div className="p-6">
          {sortedNotices.length > 0 ? <div className="space-y-6">
              {sortedNotices.map(notice => <div key={notice.id} className={`border rounded-lg overflow-hidden ${notice.pinned ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200'}`}>
                  <div className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start">
                        <div className={`p-2 rounded-md mr-4 ${notice.pinned ? 'bg-indigo-100' : 'bg-gray-100'}`}>
                          <BellIcon className={`w-5 h-5 ${notice.pinned ? 'text-indigo-600' : 'text-gray-600'}`} />
                        </div>
                        <div>
                          <h3 className="font-medium text-lg flex items-center">
                            {notice.title}
                            {notice.pinned && <span className="ml-2 bg-indigo-100 text-indigo-800 text-xs px-2 py-1 rounded">
                                Pinned
                              </span>}
                          </h3>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <CalendarIcon className="w-4 h-4 mr-1" />
                            <span>
                              {new Date(notice.date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                            </span>
                            <span className="mx-2">•</span>
                            <span>By {notice.author}</span>
                          </div>
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded text-xs ${getCategoryColor(notice.category)}`}>
                        {getCategoryName(notice.category)}
                      </div>
                    </div>
                    <div className="mt-4 text-gray-700">
                      <p>{notice.content}</p>
                    </div>
                    {userRole === 'teacher' && <div className="mt-4 flex justify-end space-x-2">
                        <button className="text-gray-500 hover:text-gray-700 p-1">
                          <TrashIcon className="w-4 h-4" />
                        </button>
                      </div>}
                  </div>
                </div>)}
            </div> : <div className="text-center py-8">
              <BellIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">
                No notices found
              </h3>
              <p className="text-gray-500 mt-1">
                {searchQuery || activeCategory !== 'all' ? 'Try adjusting your filters or search query.' : 'There are no notices at the moment.'}
              </p>
            </div>}
        </div>
      </div>
      {/* Add Notice Modal */}
      {showAddModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">Add New Notice</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddNotice} className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input type="text" required value={newNotice.title} onChange={e => setNewNotice({
              ...newNotice,
              title: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Notice title" />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <TagIcon className="h-5 w-5 text-gray-400" />
                  </div>
                  <select value={newNotice.category} onChange={e => setNewNotice({
                ...newNotice,
                category: e.target.value
              })} className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="general">General</option>
                    <option value="exam">Exam</option>
                    <option value="event">Event</option>
                    <option value="holiday">Holiday</option>
                  </select>
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Content
                </label>
                <textarea required value={newNotice.content} onChange={e => setNewNotice({
              ...newNotice,
              content: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" rows={5} placeholder="Notice content..."></textarea>
              </div>
              <div className="mb-6 flex items-center">
                <input type="checkbox" id="pinned" checked={newNotice.pinned} onChange={e => setNewNotice({
              ...newNotice,
              pinned: e.target.checked
            })} className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" />
                <label htmlFor="pinned" className="ml-2 block text-sm text-gray-700">
                  Pin this notice
                </label>
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Post Notice
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default Notices;