import React, { useState } from 'react';
import { BarChartIcon, PlusIcon, XIcon, CheckIcon, FileTextIcon, SearchIcon, CalendarIcon, ArrowUpIcon, ArrowDownIcon, ChevronDownIcon } from 'lucide-react';
const TestResults = ({
  userRole
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [selectedTest, setSelectedTest] = useState(null);
  const [sortConfig, setSortConfig] = useState({
    key: 'date',
    direction: 'desc'
  });
  const [activeSubject, setActiveSubject] = useState('all');
  // Mock data
  const subjects = [{
    id: 'all',
    name: 'All Subjects'
  }, {
    id: 'physics',
    name: 'Physics'
  }, {
    id: 'chemistry',
    name: 'Chemistry'
  }, {
    id: 'mathematics',
    name: 'Mathematics'
  }, {
    id: 'biology',
    name: 'Biology'
  }, {
    id: 'english',
    name: 'English'
  }];
  const tests = [{
    id: 1,
    title: 'Mid-Term Physics Test',
    subject: 'Physics',
    date: '2023-08-05',
    maxMarks: 100,
    yourScore: 85,
    classAverage: 72,
    highestScore: 95,
    topics: ['Mechanics', 'Thermodynamics', 'Waves']
  }, {
    id: 2,
    title: 'Chemistry Quiz 1',
    subject: 'Chemistry',
    date: '2023-07-25',
    maxMarks: 50,
    yourScore: 42,
    classAverage: 38,
    highestScore: 48,
    topics: ['Periodic Table', 'Chemical Bonding']
  }, {
    id: 3,
    title: 'Mathematics Weekly Test',
    subject: 'Mathematics',
    date: '2023-08-10',
    maxMarks: 100,
    yourScore: 78,
    classAverage: 65,
    highestScore: 92,
    topics: ['Calculus', 'Algebra']
  }, {
    id: 4,
    title: 'English Essay Evaluation',
    subject: 'English',
    date: '2023-07-15',
    maxMarks: 50,
    yourScore: 45,
    classAverage: 40,
    highestScore: 48,
    topics: ['Essay Writing', 'Comprehension']
  }, {
    id: 5,
    title: 'Biology Unit Test',
    subject: 'Biology',
    date: '2023-08-01',
    maxMarks: 100,
    yourScore: 88,
    classAverage: 76,
    highestScore: 96,
    topics: ['Cell Structure', 'Genetics']
  }];
  // For teacher view
  const students = [{
    id: 1,
    name: 'John Doe',
    roll: 'ST001',
    scores: {
      1: 85,
      2: 42,
      3: 78,
      4: 45,
      5: 88
    }
  }, {
    id: 2,
    name: 'Jane Smith',
    roll: 'ST002',
    scores: {
      1: 92,
      2: 48,
      3: 85,
      4: 44,
      5: 90
    }
  }, {
    id: 3,
    name: 'Mike Johnson',
    roll: 'ST003',
    scores: {
      1: 78,
      2: 40,
      3: 72,
      4: 42,
      5: 82
    }
  }, {
    id: 4,
    name: 'Sarah Williams',
    roll: 'ST004',
    scores: {
      1: 95,
      2: 45,
      3: 92,
      4: 48,
      5: 96
    }
  }, {
    id: 5,
    name: 'David Brown',
    roll: 'ST005',
    scores: {
      1: 65,
      2: 32,
      3: 58,
      4: 38,
      5: 72
    }
  }];
  const [newTest, setNewTest] = useState({
    title: '',
    subject: '',
    date: '',
    maxMarks: '',
    topics: ''
  });
  const [newScores, setNewScores] = useState({});
  const handleAddTest = e => {
    e.preventDefault();
    // In a real app, this would send data to the backend
    console.log('Adding test:', newTest);
    console.log('Student scores:', newScores);
    setShowAddModal(false);
    // Reset form
    setNewTest({
      title: '',
      subject: '',
      date: '',
      maxMarks: '',
      topics: ''
    });
    setNewScores({});
  };
  const handleSort = key => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({
      key,
      direction
    });
  };
  const sortedTests = [...tests].sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === 'asc' ? -1 : 1;
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });
  const filteredTests = sortedTests.filter(test => {
    const matchesSubject = activeSubject === 'all' || test.subject.toLowerCase() === activeSubject;
    const matchesSearch = test.title.toLowerCase().includes(searchQuery.toLowerCase()) || test.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });
  const handleViewDetails = test => {
    setSelectedTest(test);
    setShowDetails(true);
  };
  const getSubjectColor = subject => {
    switch (subject.toLowerCase()) {
      case 'physics':
        return 'bg-blue-100 text-blue-800';
      case 'chemistry':
        return 'bg-green-100 text-green-800';
      case 'mathematics':
        return 'bg-purple-100 text-purple-800';
      case 'biology':
        return 'bg-yellow-100 text-yellow-800';
      case 'english':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  const getPerformanceStatus = (score, max) => {
    const percentage = score / max * 100;
    if (percentage >= 90) return {
      label: 'Excellent',
      color: 'text-green-600'
    };
    if (percentage >= 75) return {
      label: 'Good',
      color: 'text-blue-600'
    };
    if (percentage >= 60) return {
      label: 'Satisfactory',
      color: 'text-yellow-600'
    };
    if (percentage >= 40) return {
      label: 'Average',
      color: 'text-orange-600'
    };
    return {
      label: 'Needs Improvement',
      color: 'text-red-600'
    };
  };
  // Calculate average score for each subject (student view)
  const getSubjectAverages = () => {
    const subjectScores = {};
    subjects.forEach(subject => {
      if (subject.id !== 'all') {
        const subjectTests = tests.filter(test => test.subject.toLowerCase() === subject.id);
        if (subjectTests.length > 0) {
          const totalScore = subjectTests.reduce((sum, test) => sum + test.yourScore / test.maxMarks * 100, 0);
          subjectScores[subject.id] = totalScore / subjectTests.length;
        }
      }
    });
    return subjectScores;
  };
  // Calculate student averages (teacher view)
  const getStudentAverages = () => {
    const studentAverages = {};
    students.forEach(student => {
      let totalPercentage = 0;
      let testCount = 0;
      tests.forEach(test => {
        if (student.scores[test.id]) {
          totalPercentage += student.scores[test.id] / test.maxMarks * 100;
          testCount++;
        }
      });
      studentAverages[student.id] = testCount > 0 ? totalPercentage / testCount : 0;
    });
    return studentAverages;
  };
  const subjectAverages = getSubjectAverages();
  const studentAverages = getStudentAverages();
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Test Results</h1>
        {userRole === 'teacher' && <button onClick={() => setShowAddModal(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" /> Add Test Results
          </button>}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6 border-b">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex overflow-x-auto pb-2 md:pb-0 scrollbar-hide space-x-2">
                  {subjects.map(subject => <button key={subject.id} className={`px-4 py-2 rounded-md whitespace-nowrap ${activeSubject === subject.id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`} onClick={() => setActiveSubject(subject.id)}>
                      {subject.name}
                    </button>)}
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon className="h-5 w-5 text-gray-400" />
                  </div>
                  <input type="text" placeholder="Search tests..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10 w-full md:w-64 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('title')}>
                      <div className="flex items-center">
                        Test Name
                        {sortConfig.key === 'title' && (sortConfig.direction === 'asc' ? <ArrowUpIcon className="w-4 h-4 ml-1" /> : <ArrowDownIcon className="w-4 h-4 ml-1" />)}
                      </div>
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('subject')}>
                      <div className="flex items-center">
                        Subject
                        {sortConfig.key === 'subject' && (sortConfig.direction === 'asc' ? <ArrowUpIcon className="w-4 h-4 ml-1" /> : <ArrowDownIcon className="w-4 h-4 ml-1" />)}
                      </div>
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('date')}>
                      <div className="flex items-center">
                        Date
                        {sortConfig.key === 'date' && (sortConfig.direction === 'asc' ? <ArrowUpIcon className="w-4 h-4 ml-1" /> : <ArrowDownIcon className="w-4 h-4 ml-1" />)}
                      </div>
                    </th>
                    {userRole === 'student' ? <>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Your Score
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </> : <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Class Average
                      </th>}
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTests.map(test => <tr key={test.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        {test.title}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-md text-xs font-medium ${getSubjectColor(test.subject)}`}>
                          {test.subject}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(test.date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                      </td>
                      {userRole === 'student' ? <>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="font-medium">
                              {test.yourScore}/{test.maxMarks}
                            </div>
                            <div className="text-xs text-gray-500">
                              {Math.round(test.yourScore / test.maxMarks * 100)}
                              %
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`${getPerformanceStatus(test.yourScore, test.maxMarks).color} text-sm font-medium`}>
                              {getPerformanceStatus(test.yourScore, test.maxMarks).label}
                            </span>
                          </td>
                        </> : <td className="px-6 py-4 whitespace-nowrap">
                          <div className="font-medium">
                            {Math.round(test.classAverage / test.maxMarks * 100)}
                            %
                          </div>
                          <div className="text-xs text-gray-500">
                            Highest: {test.highestScore}/{test.maxMarks}
                          </div>
                        </td>}
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onClick={() => handleViewDetails(test)} className="text-indigo-600 hover:text-indigo-900">
                          View Details
                        </button>
                      </td>
                    </tr>)}
                </tbody>
              </table>
              {filteredTests.length === 0 && <div className="text-center py-8">
                  <FileTextIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">
                    No tests found
                  </h3>
                  <p className="text-gray-500 mt-1">
                    {searchQuery || activeSubject !== 'all' ? 'Try adjusting your filters or search query.' : 'No test results have been added yet.'}
                  </p>
                </div>}
            </div>
          </div>
        </div>
        <div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold">Performance Summary</h2>
            </div>
            <div className="p-4">
              {userRole === 'student' ? <div>
                  <div className="mb-6">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">
                        Overall Performance
                      </span>
                      <span className="text-sm font-medium">
                        {Math.round(tests.reduce((sum, test) => sum + test.yourScore / test.maxMarks, 0) / tests.length * 100)}
                        %
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-indigo-600 h-2 rounded-full" style={{
                    width: `${Math.round(tests.reduce((sum, test) => sum + test.yourScore / test.maxMarks, 0) / tests.length * 100)}%`
                  }}></div>
                    </div>
                  </div>
                  <h3 className="font-medium text-gray-900 mb-3">
                    Subject-wise Performance
                  </h3>
                  {subjects.filter(subject => subject.id !== 'all' && subjectAverages[subject.id]).map(subject => <div key={subject.id} className="mb-4">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">{subject.name}</span>
                          <span className="text-sm font-medium">
                            {Math.round(subjectAverages[subject.id])}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className={`h-2 rounded-full ${subjectAverages[subject.id] >= 90 ? 'bg-green-500' : subjectAverages[subject.id] >= 75 ? 'bg-blue-500' : subjectAverages[subject.id] >= 60 ? 'bg-yellow-500' : subjectAverages[subject.id] >= 40 ? 'bg-orange-500' : 'bg-red-500'}`} style={{
                    width: `${Math.round(subjectAverages[subject.id])}%`
                  }}></div>
                        </div>
                      </div>)}
                  <div className="mt-6">
                    <h3 className="font-medium text-gray-900 mb-3">
                      Recent Improvements
                    </h3>
                    <div className="space-y-2">
                      {subjects.filter(subject => subject.id !== 'all' && subjectAverages[subject.id] > 75).map(subject => <div key={subject.id} className="flex items-center p-2 bg-green-50 rounded-md">
                            <div className="bg-green-100 p-1 rounded-full mr-2">
                              <CheckIcon className="w-4 h-4 text-green-600" />
                            </div>
                            <span className="text-sm text-green-800">
                              Good progress in {subject.name}
                            </span>
                          </div>)}
                      {subjects.filter(subject => subject.id !== 'all' && subjectAverages[subject.id] < 60).map(subject => <div key={subject.id} className="flex items-center p-2 bg-red-50 rounded-md">
                            <div className="bg-red-100 p-1 rounded-full mr-2">
                              <XIcon className="w-4 h-4 text-red-600" />
                            </div>
                            <span className="text-sm text-red-800">
                              Needs improvement in {subject.name}
                            </span>
                          </div>)}
                    </div>
                  </div>
                </div> : <div>
                  <div className="mb-6">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">
                        Class Average
                      </span>
                      <span className="text-sm font-medium">
                        {Math.round(tests.reduce((sum, test) => sum + test.classAverage / test.maxMarks, 0) / tests.length * 100)}
                        %
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-indigo-600 h-2 rounded-full" style={{
                    width: `${Math.round(tests.reduce((sum, test) => sum + test.classAverage / test.maxMarks, 0) / tests.length * 100)}%`
                  }}></div>
                    </div>
                  </div>
                  <h3 className="font-medium text-gray-900 mb-3">
                    Top Performers
                  </h3>
                  {Object.entries(studentAverages).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([studentId, average]) => {
                const student = students.find(s => s.id === parseInt(studentId));
                return <div key={studentId} className="flex items-center justify-between mb-3 p-2 bg-gray-50 rounded-md">
                          <div className="flex items-center">
                            <div className="bg-indigo-100 p-2 rounded-full mr-2">
                              <UserIcon className="w-4 h-4 text-indigo-600" />
                            </div>
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-xs text-gray-500">
                                {student.roll}
                              </div>
                            </div>
                          </div>
                          <div className="text-sm font-medium">
                            {Math.round(average)}%
                          </div>
                        </div>;
              })}
                  <h3 className="font-medium text-gray-900 mb-3 mt-6">
                    Subject Breakdown
                  </h3>
                  {subjects.filter(subject => subject.id !== 'all').map(subject => {
                const subjectTests = tests.filter(test => test.subject.toLowerCase() === subject.id);
                const average = subjectTests.length > 0 ? subjectTests.reduce((sum, test) => sum + test.classAverage / test.maxMarks, 0) / subjectTests.length * 100 : 0;
                return <div key={subject.id} className="mb-4">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">{subject.name}</span>
                            <span className="text-sm font-medium">
                              {Math.round(average)}%
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className={`h-2 rounded-full ${average >= 80 ? 'bg-green-500' : average >= 70 ? 'bg-blue-500' : average >= 60 ? 'bg-yellow-500' : average >= 50 ? 'bg-orange-500' : 'bg-red-500'}`} style={{
                      width: `${Math.round(average)}%`
                    }}></div>
                          </div>
                        </div>;
              })}
                </div>}
            </div>
          </div>
        </div>
      </div>
      {/* Test Details Modal */}
      {showDetails && selectedTest && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">{selectedTest.title}</h3>
              <button onClick={() => setShowDetails(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <div className="text-sm text-gray-500">Subject</div>
                    <div className="font-medium">{selectedTest.subject}</div>
                  </div>
                  <div className="mb-4">
                    <div className="text-sm text-gray-500">Date</div>
                    <div className="font-medium">
                      {new Date(selectedTest.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                    </div>
                  </div>
                  <div className="mb-4">
                    <div className="text-sm text-gray-500">Topics Covered</div>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {selectedTest.topics.map((topic, index) => <span key={index} className="bg-gray-100 text-gray-800 text-xs font-medium px-2 py-1 rounded-md">
                          {topic}
                        </span>)}
                    </div>
                  </div>
                </div>
                <div>
                  {userRole === 'student' ? <>
                      <div className="mb-4">
                        <div className="text-sm text-gray-500">Your Score</div>
                        <div className="text-2xl font-bold">
                          {selectedTest.yourScore}/{selectedTest.maxMarks}
                          <span className="text-sm text-gray-500 ml-2">
                            (
                            {Math.round(selectedTest.yourScore / selectedTest.maxMarks * 100)}
                            %)
                          </span>
                        </div>
                      </div>
                      <div className="mb-4">
                        <div className="text-sm text-gray-500">Performance</div>
                        <div className={`font-medium ${getPerformanceStatus(selectedTest.yourScore, selectedTest.maxMarks).color}`}>
                          {getPerformanceStatus(selectedTest.yourScore, selectedTest.maxMarks).label}
                        </div>
                      </div>
                      <div className="mb-4">
                        <div className="text-sm text-gray-500">
                          Class Statistics
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-2">
                          <div className="bg-gray-50 p-3 rounded-md text-center">
                            <div className="text-sm text-gray-500">
                              Class Average
                            </div>
                            <div className="font-medium">
                              {Math.round(selectedTest.classAverage / selectedTest.maxMarks * 100)}
                              %
                            </div>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-md text-center">
                            <div className="text-sm text-gray-500">
                              Highest Score
                            </div>
                            <div className="font-medium">
                              {selectedTest.highestScore}/
                              {selectedTest.maxMarks}
                            </div>
                          </div>
                        </div>
                      </div>
                    </> : <>
                      <div className="mb-4">
                        <div className="text-sm text-gray-500">
                          Class Statistics
                        </div>
                        <div className="grid grid-cols-3 gap-2 mt-2">
                          <div className="bg-gray-50 p-3 rounded-md text-center">
                            <div className="text-sm text-gray-500">Average</div>
                            <div className="font-medium">
                              {Math.round(selectedTest.classAverage / selectedTest.maxMarks * 100)}
                              %
                            </div>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-md text-center">
                            <div className="text-sm text-gray-500">Highest</div>
                            <div className="font-medium">
                              {selectedTest.highestScore}/
                              {selectedTest.maxMarks}
                            </div>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-md text-center">
                            <div className="text-sm text-gray-500">
                              Max Marks
                            </div>
                            <div className="font-medium">
                              {selectedTest.maxMarks}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="mb-4">
                        <div className="text-sm text-gray-500 mb-2">
                          Student Scores
                        </div>
                        <div className="max-h-48 overflow-y-auto border rounded-md">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Student
                                </th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Score
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {students.map(student => <tr key={student.id}>
                                  <td className="px-4 py-2 whitespace-nowrap">
                                    <div className="font-medium">
                                      {student.name}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {student.roll}
                                    </div>
                                  </td>
                                  <td className="px-4 py-2 whitespace-nowrap">
                                    <div className="font-medium">
                                      {student.scores[selectedTest.id]}/
                                      {selectedTest.maxMarks}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {Math.round(student.scores[selectedTest.id] / selectedTest.maxMarks * 100)}
                                      %
                                    </div>
                                  </td>
                                </tr>)}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </>}
                </div>
              </div>
              {userRole === 'student' && <div className="mt-4 p-4 bg-indigo-50 rounded-md">
                  <h4 className="font-medium text-indigo-800 mb-2">
                    Teacher's Feedback
                  </h4>
                  <p className="text-indigo-700 text-sm">
                    {selectedTest.yourScore >= selectedTest.maxMarks * 0.8 ? 'Excellent work! You have a strong understanding of the concepts covered. Keep up the good work.' : selectedTest.yourScore >= selectedTest.maxMarks * 0.6 ? 'Good effort. You understand most concepts but need to work on a few areas. Review the topics where you lost marks.' : 'You need to focus more on understanding the core concepts. Please schedule a review session to discuss areas for improvement.'}
                  </p>
                </div>}
            </div>
            <div className="p-6 border-t flex justify-end">
              <button onClick={() => setShowDetails(false)} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                Close
              </button>
            </div>
          </div>
        </div>}
      {/* Add Test Results Modal */}
      {showAddModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white">
              <h3 className="text-lg font-bold">Add Test Results</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddTest}>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Test Title
                    </label>
                    <input type="text" required value={newTest.title} onChange={e => setNewTest({
                  ...newTest,
                  title: e.target.value
                })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Mid-Term Physics Test" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject
                    </label>
                    <select required value={newTest.subject} onChange={e => setNewTest({
                  ...newTest,
                  subject: e.target.value
                })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                      <option value="">Select a subject</option>
                      <option value="Physics">Physics</option>
                      <option value="Chemistry">Chemistry</option>
                      <option value="Mathematics">Mathematics</option>
                      <option value="Biology">Biology</option>
                      <option value="English">English</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Test Date
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <CalendarIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <input type="date" required value={newTest.date} onChange={e => setNewTest({
                    ...newTest,
                    date: e.target.value
                  })} className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Maximum Marks
                    </label>
                    <input type="number" required min="1" value={newTest.maxMarks} onChange={e => setNewTest({
                  ...newTest,
                  maxMarks: e.target.value
                })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g., 100" />
                  </div>
                </div>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Topics Covered (comma separated)
                  </label>
                  <input type="text" value={newTest.topics} onChange={e => setNewTest({
                ...newTest,
                topics: e.target.value
              })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Mechanics, Thermodynamics, Waves" />
                </div>
                <div className="mb-6">
                  <h4 className="font-medium mb-3">Student Scores</h4>
                  <div className="border rounded-md overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Student
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Roll Number
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Score
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {students.map(student => <tr key={student.id}>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {student.name}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {student.roll}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <input type="number" min="0" max={newTest.maxMarks || 100} value={newScores[student.id] || ''} onChange={e => setNewScores({
                          ...newScores,
                          [student.id]: e.target.value
                        })} className="w-20 px-2 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500" />
                              <span className="text-xs text-gray-500 ml-2">
                                / {newTest.maxMarks || '...'}
                              </span>
                            </td>
                          </tr>)}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div className="p-6 border-t flex justify-end space-x-3 sticky bottom-0 bg-white">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Save Test Results
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default TestResults;