import React, { useState } from 'react';
import { VideoIcon, PlayIcon, ClockIcon, CalendarIcon, PlusIcon, UsersIcon, CheckIcon, XIcon } from 'lucide-react';
const LiveLectures = ({
  userRole
}) => {
  const [activeTab, setActiveTab] = useState('upcoming');
  // Mock data
  const upcomingLectures = [{
    id: 1,
    subject: 'Physics',
    topic: 'Quantum Mechanics',
    teacher: 'Dr. Smith',
    date: '2023-08-15',
    time: '15:00',
    duration: '60 min',
    students: 28
  }, {
    id: 2,
    subject: 'Mathematics',
    topic: 'Calculus Integration',
    teacher: 'Prof. Johnson',
    date: '2023-08-16',
    time: '10:00',
    duration: '90 min',
    students: 32
  }, {
    id: 3,
    subject: 'Chemistry',
    topic: 'Organic Compounds',
    teacher: 'Dr. Williams',
    date: '2023-08-17',
    time: '14:00',
    duration: '60 min',
    students: 25
  }];
  const pastLectures = [{
    id: 4,
    subject: 'Physics',
    topic: 'Wave Theory',
    teacher: 'Dr. Smith',
    date: '2023-08-10',
    time: '15:00',
    duration: '60 min',
    recordingUrl: 'https://example.com/recording1',
    students: 26
  }, {
    id: 5,
    subject: 'Mathematics',
    topic: 'Differential Equations',
    teacher: 'Prof. Johnson',
    date: '2023-08-09',
    time: '10:00',
    duration: '90 min',
    recordingUrl: 'https://example.com/recording2',
    students: 30
  }, {
    id: 6,
    subject: 'Chemistry',
    topic: 'Periodic Table',
    teacher: 'Dr. Williams',
    date: '2023-08-08',
    time: '14:00',
    duration: '60 min',
    recordingUrl: 'https://example.com/recording3',
    students: 28
  }];
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [newLecture, setNewLecture] = useState({
    subject: '',
    topic: '',
    date: '',
    time: '',
    duration: '60'
  });
  const handleScheduleLecture = e => {
    e.preventDefault();
    // In a real app, this would send data to the backend
    console.log('Scheduling lecture:', newLecture);
    setShowScheduleModal(false);
    // Reset form
    setNewLecture({
      subject: '',
      topic: '',
      date: '',
      time: '',
      duration: '60'
    });
  };
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Live Lectures</h1>
        {userRole === 'teacher' && <button onClick={() => setShowScheduleModal(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" /> Schedule Lecture
          </button>}
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="flex border-b">
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'upcoming' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('upcoming')}>
            Upcoming Lectures
          </button>
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'past' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('past')}>
            Past Recordings
          </button>
        </div>
        <div className="p-6">
          {activeTab === 'upcoming' ? <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingLectures.map(lecture => <div key={lecture.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-indigo-600 text-white p-4">
                    <h3 className="font-bold text-lg">{lecture.subject}</h3>
                    <p>{lecture.topic}</p>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <UsersIcon className="w-4 h-4 mr-2" />
                      <span>Teacher: {lecture.teacher}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      <span>
                        {new Date(lecture.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                      </span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <ClockIcon className="w-4 h-4 mr-2" />
                      <span>
                        {lecture.time} • {lecture.duration}
                      </span>
                    </div>
                    {userRole === 'teacher' && <div className="flex items-center text-sm text-gray-600 mb-4">
                        <UsersIcon className="w-4 h-4 mr-2" />
                        <span>{lecture.students} students enrolled</span>
                      </div>}
                    <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-md flex items-center justify-center mt-2">
                      <VideoIcon className="w-4 h-4 mr-2" />
                      {new Date(`${lecture.date}T${lecture.time}`) <= new Date() ? 'Join Now' : 'Remind Me'}
                    </button>
                  </div>
                </div>)}
            </div> : <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pastLectures.map(lecture => <div key={lecture.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-700 text-white p-4">
                    <h3 className="font-bold text-lg">{lecture.subject}</h3>
                    <p>{lecture.topic}</p>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <UsersIcon className="w-4 h-4 mr-2" />
                      <span>Teacher: {lecture.teacher}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      <span>
                        {new Date(lecture.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                      </span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <ClockIcon className="w-4 h-4 mr-2" />
                      <span>
                        {lecture.time} • {lecture.duration}
                      </span>
                    </div>
                    {userRole === 'teacher' && <div className="flex items-center text-sm text-gray-600 mb-4">
                        <UsersIcon className="w-4 h-4 mr-2" />
                        <span>{lecture.students} students viewed</span>
                      </div>}
                    <button className="w-full bg-gray-700 hover:bg-gray-800 text-white py-2 rounded-md flex items-center justify-center mt-2">
                      <PlayIcon className="w-4 h-4 mr-2" />
                      Watch Recording
                    </button>
                  </div>
                </div>)}
            </div>}
          {activeTab === 'upcoming' && upcomingLectures.length === 0 && <div className="text-center py-8">
              <VideoIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">
                No upcoming lectures
              </h3>
              <p className="text-gray-500 mt-1">
                Check back later for scheduled lectures.
              </p>
            </div>}
          {activeTab === 'past' && pastLectures.length === 0 && <div className="text-center py-8">
              <VideoIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">
                No past recordings
              </h3>
              <p className="text-gray-500 mt-1">
                Recordings will appear here after lectures are completed.
              </p>
            </div>}
        </div>
      </div>
      {/* Schedule Lecture Modal */}
      {showScheduleModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">Schedule New Lecture</h3>
              <button onClick={() => setShowScheduleModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleScheduleLecture} className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <input type="text" required value={newLecture.subject} onChange={e => setNewLecture({
              ...newLecture,
              subject: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Topic
                </label>
                <input type="text" required value={newLecture.topic} onChange={e => setNewLecture({
              ...newLecture,
              topic: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date
                  </label>
                  <input type="date" required value={newLecture.date} onChange={e => setNewLecture({
                ...newLecture,
                date: e.target.value
              })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Time
                  </label>
                  <input type="time" required value={newLecture.time} onChange={e => setNewLecture({
                ...newLecture,
                time: e.target.value
              })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Duration (minutes)
                </label>
                <select value={newLecture.duration} onChange={e => setNewLecture({
              ...newLecture,
              duration: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="30">30 minutes</option>
                  <option value="45">45 minutes</option>
                  <option value="60">60 minutes</option>
                  <option value="90">90 minutes</option>
                  <option value="120">120 minutes</option>
                </select>
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowScheduleModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Schedule Lecture
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default LiveLectures;