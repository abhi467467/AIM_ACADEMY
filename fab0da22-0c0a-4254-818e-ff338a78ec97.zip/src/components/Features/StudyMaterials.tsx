import React, { useState } from 'react';
import { FileTextIcon, BookOpenIcon, FolderIcon, DownloadIcon, PlusIcon, SearchIcon, XIcon, CheckIcon, FileIcon, BookIcon, VideoIcon } from 'lucide-react';
const StudyMaterials = ({
  userRole
}) => {
  const [activeSubject, setActiveSubject] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [newMaterial, setNewMaterial] = useState({
    title: '',
    subject: '',
    type: 'document',
    file: null
  });
  // Mock data
  const subjects = [{
    id: 'all',
    name: 'All Subjects'
  }, {
    id: 'physics',
    name: 'Physics'
  }, {
    id: 'chemistry',
    name: 'Chemistry'
  }, {
    id: 'mathematics',
    name: 'Mathematics'
  }, {
    id: 'biology',
    name: 'Biology'
  }, {
    id: 'english',
    name: 'English'
  }];
  const materials = [{
    id: 1,
    title: 'Quantum Mechanics Notes',
    subject: 'Physics',
    type: 'document',
    fileType: 'pdf',
    size: '2.4 MB',
    uploadDate: '2023-08-01',
    uploadedBy: 'Dr. Smith'
  }, {
    id: 2,
    title: 'Calculus Formulas',
    subject: 'Mathematics',
    type: 'document',
    fileType: 'pdf',
    size: '1.8 MB',
    uploadDate: '2023-08-02',
    uploadedBy: 'Prof. Johnson'
  }, {
    id: 3,
    title: 'Organic Chemistry Basics',
    subject: 'Chemistry',
    type: 'presentation',
    fileType: 'ppt',
    size: '5.2 MB',
    uploadDate: '2023-08-03',
    uploadedBy: 'Dr. Williams'
  }, {
    id: 4,
    title: 'Cell Structure Diagram',
    subject: 'Biology',
    type: 'image',
    fileType: 'jpg',
    size: '1.1 MB',
    uploadDate: '2023-08-04',
    uploadedBy: 'Dr. Brown'
  }, {
    id: 5,
    title: 'Essay Writing Guidelines',
    subject: 'English',
    type: 'document',
    fileType: 'pdf',
    size: '0.9 MB',
    uploadDate: '2023-08-05',
    uploadedBy: 'Prof. Davis'
  }, {
    id: 6,
    title: 'Thermodynamics Recorded Lecture',
    subject: 'Physics',
    type: 'video',
    fileType: 'mp4',
    size: '45.6 MB',
    uploadDate: '2023-08-06',
    uploadedBy: 'Dr. Smith'
  }];
  const filteredMaterials = materials.filter(material => {
    const matchesSubject = activeSubject === 'all' || material.subject.toLowerCase() === activeSubject;
    const matchesSearch = material.title.toLowerCase().includes(searchQuery.toLowerCase()) || material.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });
  const handleUpload = e => {
    e.preventDefault();
    // In a real app, this would upload the file to the backend
    console.log('Uploading material:', newMaterial);
    setShowUploadModal(false);
    // Reset form
    setNewMaterial({
      title: '',
      subject: '',
      type: 'document',
      file: null
    });
  };
  const getFileIcon = type => {
    switch (type) {
      case 'document':
        return <FileTextIcon className="w-8 h-8 text-blue-500" />;
      case 'presentation':
        return <FileIcon className="w-8 h-8 text-orange-500" />;
      case 'image':
        return <FileIcon className="w-8 h-8 text-green-500" />;
      case 'video':
        return <VideoIcon className="w-8 h-8 text-red-500" />;
      default:
        return <FileIcon className="w-8 h-8 text-gray-500" />;
    }
  };
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Study Materials</h1>
        {userRole === 'teacher' && <button onClick={() => setShowUploadModal(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" /> Upload Material
          </button>}
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex overflow-x-auto pb-2 md:pb-0 scrollbar-hide space-x-2">
              {subjects.map(subject => <button key={subject.id} className={`px-4 py-2 rounded-md whitespace-nowrap ${activeSubject === subject.id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`} onClick={() => setActiveSubject(subject.id)}>
                  {subject.name}
                </button>)}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" placeholder="Search materials..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10 w-full md:w-64 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
          </div>
        </div>
        <div className="p-6">
          {filteredMaterials.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMaterials.map(material => <div key={material.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="p-5">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        {getFileIcon(material.type)}
                      </div>
                      <div className="ml-3 flex-1">
                        <h3 className="font-medium text-gray-900">
                          {material.title}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {material.subject}
                        </p>
                        <div className="flex items-center text-xs text-gray-500 mt-2">
                          <span>{material.fileType.toUpperCase()}</span>
                          <span className="mx-1">•</span>
                          <span>{material.size}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="text-xs text-gray-500">
                        Uploaded on{' '}
                        {new Date(material.uploadDate).toLocaleDateString()}
                        <br />
                        by {material.uploadedBy}
                      </div>
                      <button className="flex items-center text-indigo-600 hover:text-indigo-800">
                        <DownloadIcon className="w-4 h-4 mr-1" />
                        <span className="text-sm">Download</span>
                      </button>
                    </div>
                  </div>
                </div>)}
            </div> : <div className="text-center py-8">
              <BookOpenIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">
                No materials found
              </h3>
              <p className="text-gray-500 mt-1">
                {searchQuery ? 'Try adjusting your search query.' : 'No materials have been uploaded for this subject yet.'}
              </p>
            </div>}
        </div>
      </div>
      {/* Upload Material Modal */}
      {showUploadModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">Upload Study Material</h3>
              <button onClick={() => setShowUploadModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpload} className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input type="text" required value={newMaterial.title} onChange={e => setNewMaterial({
              ...newMaterial,
              title: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Physics Notes Chapter 5" />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <select required value={newMaterial.subject} onChange={e => setNewMaterial({
              ...newMaterial,
              subject: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">Select a subject</option>
                  <option value="Physics">Physics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Biology">Biology</option>
                  <option value="English">English</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Material Type
                </label>
                <select value={newMaterial.type} onChange={e => setNewMaterial({
              ...newMaterial,
              type: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="document">Document (PDF)</option>
                  <option value="presentation">Presentation (PPT)</option>
                  <option value="image">Image</option>
                  <option value="video">Video</option>
                </select>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upload File
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                  <input type="file" required onChange={e => setNewMaterial({
                ...newMaterial,
                file: e.target.files[0]
              })} className="hidden" id="file-upload" />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <FolderIcon className="w-10 h-10 text-gray-400 mx-auto mb-3" />
                    <p className="text-sm text-gray-500">
                      <span className="text-indigo-600 hover:underline">
                        Click to upload
                      </span>{' '}
                      or drag and drop
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      PDF, PPT, JPG, PNG, MP4 (max. 100MB)
                    </p>
                  </label>
                  {newMaterial.file && <div className="mt-3 text-sm text-gray-800">
                      Selected: {newMaterial.file.name}
                    </div>}
                </div>
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowUploadModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Upload Material
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default StudyMaterials;