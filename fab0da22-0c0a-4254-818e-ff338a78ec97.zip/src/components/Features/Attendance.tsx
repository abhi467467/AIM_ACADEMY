import React, { useState } from 'react';
import { CalendarIcon, CheckIcon, XIcon, UserIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
const Attendance = ({
  userRole
}) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showMarkModal, setShowMarkModal] = useState(false);
  const [attendanceStatus, setAttendanceStatus] = useState({});
  // Mock data
  const students = [{
    id: 1,
    name: 'John Doe',
    roll: 'ST001'
  }, {
    id: 2,
    name: 'Jane Smith',
    roll: 'ST002'
  }, {
    id: 3,
    name: 'Mike Johnson',
    roll: 'ST003'
  }, {
    id: 4,
    name: 'Sarah Williams',
    roll: 'ST004'
  }, {
    id: 5,
    name: 'David Brown',
    roll: 'ST005'
  }];
  // Mock attendance data - in a real app, this would come from the backend
  const attendanceData = {
    '2023-08-01': {
      1: 'present',
      2: 'present',
      3: 'present',
      4: 'absent',
      5: 'present'
    },
    '2023-08-02': {
      1: 'present',
      2: 'absent',
      3: 'present',
      4: 'present',
      5: 'present'
    },
    '2023-08-03': {
      1: 'present',
      2: 'present',
      3: 'present',
      4: 'present',
      5: 'absent'
    },
    '2023-08-04': {
      1: 'absent',
      2: 'present',
      3: 'absent',
      4: 'present',
      5: 'present'
    },
    '2023-08-07': {
      1: 'present',
      2: 'present',
      3: 'present',
      4: 'present',
      5: 'present'
    },
    '2023-08-08': {
      1: 'present',
      2: 'present',
      3: 'present',
      4: 'absent',
      5: 'present'
    },
    '2023-08-09': {
      1: 'present',
      2: 'absent',
      3: 'present',
      4: 'present',
      5: 'present'
    },
    '2023-08-10': {
      1: 'absent',
      2: 'present',
      3: 'present',
      4: 'present',
      5: 'present'
    },
    '2023-08-11': {
      1: 'present',
      2: 'present',
      3: 'absent',
      4: 'present',
      5: 'present'
    }
  };
  // Holiday data
  const holidays = ['2023-08-15', '2023-08-25' // Teacher's Day
  ];
  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };
  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };
  const handleDateClick = date => {
    setSelectedDate(date);
    // For teachers, open the attendance marking modal when clicking on a date
    if (userRole === 'teacher' && isSameMonth(date, currentMonth) && !isHoliday(formatDate(date))) {
      setShowMarkModal(true);
      // Initialize with existing attendance data for the selected date
      const dateStr = formatDate(date);
      if (attendanceData[dateStr]) {
        setAttendanceStatus(attendanceData[dateStr]);
      } else {
        // Default all students to present
        const defaultStatus = {};
        students.forEach(student => {
          defaultStatus[student.id] = 'present';
        });
        setAttendanceStatus(defaultStatus);
      }
    }
  };
  const handleMarkAttendance = () => {
    // In a real app, this would send data to the backend
    console.log('Marking attendance for', formatDate(selectedDate), attendanceStatus);
    setShowMarkModal(false);
  };
  const toggleAttendanceStatus = studentId => {
    setAttendanceStatus(prev => ({
      ...prev,
      [studentId]: prev[studentId] === 'present' ? 'absent' : 'present'
    }));
  };
  // Helper functions
  const formatDate = date => {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };
  const isToday = date => {
    const today = new Date();
    return date.getDate() === today.getDate() && date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
  };
  const isSameMonth = (date, monthDate) => {
    return date.getMonth() === monthDate.getMonth() && date.getFullYear() === monthDate.getFullYear();
  };
  const isSelected = date => {
    return date.getDate() === selectedDate.getDate() && date.getMonth() === selectedDate.getMonth() && date.getFullYear() === selectedDate.getFullYear();
  };
  const isHoliday = dateStr => {
    return holidays.includes(dateStr);
  };
  const getMonthDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const days = [];
    // Add days from previous month to fill the first week
    const prevMonth = new Date(year, month - 1, 1);
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      days.push({
        date: new Date(year, month - 1, daysInPrevMonth - i),
        isCurrentMonth: false
      });
    }
    // Add days of current month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push({
        date: new Date(year, month, day),
        isCurrentMonth: true
      });
    }
    // Add days from next month to complete the last week
    const remainingDays = 42 - days.length; // 6 rows of 7 days
    for (let day = 1; day <= remainingDays; day++) {
      days.push({
        date: new Date(year, month + 1, day),
        isCurrentMonth: false
      });
    }
    return days;
  };
  const getAttendanceStatusForDate = (date, studentId) => {
    const dateStr = formatDate(date);
    if (isHoliday(dateStr)) return 'holiday';
    if (attendanceData[dateStr] && attendanceData[dateStr][studentId]) {
      return attendanceData[dateStr][studentId];
    }
    return null;
  };
  const getAttendanceColor = status => {
    switch (status) {
      case 'present':
        return 'bg-green-500';
      case 'absent':
        return 'bg-red-500';
      case 'holiday':
        return 'bg-blue-500';
      default:
        return 'bg-gray-200';
    }
  };
  const getDayAttendanceSummary = date => {
    const dateStr = formatDate(date);
    if (isHoliday(dateStr)) return {
      present: 0,
      absent: 0,
      total: 0,
      holiday: true
    };
    if (!attendanceData[dateStr]) return null;
    const summary = {
      present: 0,
      absent: 0,
      total: 0,
      holiday: false
    };
    Object.values(attendanceData[dateStr]).forEach(status => {
      if (status === 'present') summary.present++;else if (status === 'absent') summary.absent++;
      summary.total++;
    });
    return summary;
  };
  const getMonthAttendanceSummary = () => {
    const summary = {
      present: 0,
      absent: 0,
      total: 0,
      days: 0
    };
    Object.keys(attendanceData).forEach(dateStr => {
      const date = new Date(dateStr);
      if (date.getMonth() === currentMonth.getMonth() && date.getFullYear() === currentMonth.getFullYear()) {
        Object.values(attendanceData[dateStr]).forEach(status => {
          if (status === 'present') summary.present++;else if (status === 'absent') summary.absent++;
          summary.total++;
        });
        summary.days++;
      }
    });
    return summary;
  };
  // Get student's monthly attendance
  const getStudentMonthlyAttendance = studentId => {
    const summary = {
      present: 0,
      absent: 0,
      total: 0
    };
    Object.keys(attendanceData).forEach(dateStr => {
      const date = new Date(dateStr);
      if (date.getMonth() === currentMonth.getMonth() && date.getFullYear() === currentMonth.getFullYear() && !isHoliday(dateStr)) {
        if (attendanceData[dateStr][studentId]) {
          if (attendanceData[dateStr][studentId] === 'present') summary.present++;else if (attendanceData[dateStr][studentId] === 'absent') summary.absent++;
          summary.total++;
        }
      }
    });
    return summary;
  };
  const monthDays = getMonthDays();
  const monthAttendanceSummary = getMonthAttendanceSummary();
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Attendance</h1>
        {userRole === 'teacher' && <button onClick={() => {
        setSelectedDate(new Date());
        setShowMarkModal(true);
      }} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <CalendarIcon className="w-4 h-4 mr-2" /> Mark Today's Attendance
          </button>}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 flex items-center justify-between border-b">
              <h2 className="text-lg font-semibold">Attendance Calendar</h2>
              <div className="flex items-center space-x-4">
                <button onClick={handlePrevMonth} className="p-1 rounded-full hover:bg-gray-100">
                  <ChevronLeftIcon className="w-5 h-5" />
                </button>
                <span className="text-lg">
                  {currentMonth.toLocaleDateString('en-US', {
                  month: 'long',
                  year: 'numeric'
                })}
                </span>
                <button onClick={handleNextMonth} className="p-1 rounded-full hover:bg-gray-100">
                  <ChevronRightIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-7 gap-2 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => <div key={index} className="text-center font-medium text-gray-500">
                      {day}
                    </div>)}
              </div>
              <div className="grid grid-cols-7 gap-2">
                {monthDays.map((day, index) => {
                const dateStr = formatDate(day.date);
                const isHolidayDate = isHoliday(dateStr);
                const attendanceSummary = getDayAttendanceSummary(day.date);
                return <button key={index} className={`
                        p-1 rounded-md flex flex-col items-center justify-center h-16
                        ${!day.isCurrentMonth ? 'text-gray-400' : ''}
                        ${isToday(day.date) ? 'border border-indigo-500' : ''}
                        ${isSelected(day.date) ? 'bg-indigo-100' : ''}
                      `} onClick={() => handleDateClick(day.date)} disabled={!day.isCurrentMonth}>
                      <span className={`
                        text-sm font-medium
                        ${isSelected(day.date) ? 'text-indigo-800' : ''}
                      `}>
                        {day.date.getDate()}
                      </span>
                      {day.isCurrentMonth && <div className="mt-1">
                          {isHolidayDate ? <div className="w-4 h-4 rounded-full bg-blue-500"></div> : attendanceSummary ? <div className="flex space-x-1">
                              {attendanceSummary.present > 0 && <div className="w-2 h-2 rounded-full bg-green-500"></div>}
                              {attendanceSummary.absent > 0 && <div className="w-2 h-2 rounded-full bg-red-500"></div>}
                            </div> : null}
                        </div>}
                    </button>;
              })}
              </div>
              <div className="mt-4 flex items-center justify-center space-x-6 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                  <span>Present</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                  <span>Absent</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                  <span>Holiday</span>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden mt-6">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold">
                {selectedDate.toLocaleDateString('en-US', {
                weekday: 'long',
                month: 'long',
                day: 'numeric',
                year: 'numeric'
              })}
              </h2>
            </div>
            <div className="p-4">
              {isHoliday(formatDate(selectedDate)) ? <div className="text-center py-8">
                  <CalendarIcon className="w-12 h-12 text-blue-500 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">Holiday</h3>
                  <p className="text-gray-500 mt-1">
                    No attendance marked for holidays.
                  </p>
                </div> : attendanceData[formatDate(selectedDate)] ? <div>
                  {userRole === 'teacher' ? <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead>
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Student
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Roll Number
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {students.map(student => <tr key={student.id}>
                              <td className="px-4 py-3 whitespace-nowrap">
                                {student.name}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                {student.roll}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className={`
                                  px-2 py-1 rounded-full text-xs font-medium
                                  ${attendanceData[formatDate(selectedDate)][student.id] === 'present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                                `}>
                                  {attendanceData[formatDate(selectedDate)][student.id] === 'present' ? 'Present' : 'Absent'}
                                </span>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <button className={`
                                    px-2 py-1 rounded text-xs border
                                    ${attendanceData[formatDate(selectedDate)][student.id] === 'present' ? 'border-red-300 text-red-700 hover:bg-red-50' : 'border-green-300 text-green-700 hover:bg-green-50'}
                                  `}>
                                  Mark{' '}
                                  {attendanceData[formatDate(selectedDate)][student.id] === 'present' ? 'Absent' : 'Present'}
                                </button>
                              </td>
                            </tr>)}
                        </tbody>
                      </table>
                    </div> : <div className="text-center py-8">
                      <div className={`
                        w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center
                        ${attendanceData[formatDate(selectedDate)][1] === 'present' ? 'bg-green-100' : 'bg-red-100'}
                      `}>
                        {attendanceData[formatDate(selectedDate)][1] === 'present' ? <CheckIcon className="w-8 h-8 text-green-600" /> : <XIcon className="w-8 h-8 text-red-600" />}
                      </div>
                      <h3 className="text-lg font-medium text-gray-900">
                        You were{' '}
                        {attendanceData[formatDate(selectedDate)][1] === 'present' ? 'Present' : 'Absent'}
                      </h3>
                      <p className="text-gray-500 mt-1">
                        {attendanceData[formatDate(selectedDate)][1] === 'present' ? 'Your attendance was marked for this day.' : 'You were marked absent on this day.'}
                      </p>
                    </div>}
                </div> : <div className="text-center py-8">
                  <CalendarIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">
                    No Attendance Data
                  </h3>
                  <p className="text-gray-500 mt-1">
                    Attendance has not been marked for this date.
                  </p>
                  {userRole === 'teacher' && <button onClick={() => setShowMarkModal(true)} className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                      Mark Attendance
                    </button>}
                </div>}
            </div>
          </div>
        </div>
        <div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold">Monthly Summary</h2>
            </div>
            <div className="p-4">
              <div className="mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-500">
                    Overall Attendance
                  </span>
                  <span className="text-sm font-medium">
                    {monthAttendanceSummary.present} /{' '}
                    {monthAttendanceSummary.total} days
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{
                  width: `${monthAttendanceSummary.total ? monthAttendanceSummary.present / monthAttendanceSummary.total * 100 : 0}%`
                }}></div>
                </div>
                <div className="text-right text-xs text-gray-500 mt-1">
                  {monthAttendanceSummary.total ? Math.round(monthAttendanceSummary.present / monthAttendanceSummary.total * 100) : 0}
                  % present
                </div>
              </div>
              <div className="flex justify-between text-center mb-6">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {monthAttendanceSummary.present}
                  </div>
                  <div className="text-xs text-gray-500">Present</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">
                    {monthAttendanceSummary.absent}
                  </div>
                  <div className="text-xs text-gray-500">Absent</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">
                    {holidays.filter(h => {
                    const date = new Date(h);
                    return date.getMonth() === currentMonth.getMonth() && date.getFullYear() === currentMonth.getFullYear();
                  }).length}
                  </div>
                  <div className="text-xs text-gray-500">Holidays</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">
                    {monthAttendanceSummary.days}
                  </div>
                  <div className="text-xs text-gray-500">Working Days</div>
                </div>
              </div>
              {userRole === 'teacher' && <div>
                  <h3 className="font-medium mb-3">Student Attendance</h3>
                  {students.map(student => {
                const summary = getStudentMonthlyAttendance(student.id);
                const percentage = summary.total ? Math.round(summary.present / summary.total * 100) : 0;
                return <div key={student.id} className="mb-4">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">{student.name}</span>
                          <span className="text-sm font-medium">
                            {percentage}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className={`h-2 rounded-full ${percentage >= 75 ? 'bg-green-500' : percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{
                      width: `${percentage}%`
                    }}></div>
                        </div>
                      </div>;
              })}
                </div>}
              {userRole === 'student' && <div>
                  <h3 className="font-medium mb-3">Your Attendance Details</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center justify-center">
                      <div className="w-24 h-24 relative">
                        <svg className="w-full h-full" viewBox="0 0 36 36">
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e5e7eb" strokeWidth="3" />
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke={monthAttendanceSummary.total && monthAttendanceSummary.present / monthAttendanceSummary.total >= 0.75 ? '#10b981' : '#ef4444'} strokeWidth="3" strokeDasharray={`${monthAttendanceSummary.total ? monthAttendanceSummary.present / monthAttendanceSummary.total * 100 : 0}, 100`} strokeLinecap="round" />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center flex-col">
                          <span className="text-2xl font-bold">
                            {monthAttendanceSummary.total ? Math.round(monthAttendanceSummary.present / monthAttendanceSummary.total * 100) : 0}
                            %
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 text-center">
                      {monthAttendanceSummary.total && monthAttendanceSummary.present / monthAttendanceSummary.total >= 0.75 ? <p className="text-green-600">
                          Your attendance is good!
                        </p> : <p className="text-red-600">
                          Your attendance needs improvement!
                        </p>}
                    </div>
                  </div>
                </div>}
            </div>
          </div>
        </div>
      </div>
      {/* Mark Attendance Modal */}
      {showMarkModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">
                Mark Attendance -{' '}
                {selectedDate.toLocaleDateString('en-US', {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
              year: 'numeric'
            })}
              </h3>
              <button onClick={() => setShowMarkModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              <div className="space-y-4">
                {students.map(student => <div key={student.id} className="flex items-center justify-between p-3 border rounded-md">
                    <div className="flex items-center">
                      <div className="bg-gray-100 p-2 rounded-full mr-3">
                        <UserIcon className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{student.name}</h4>
                        <p className="text-sm text-gray-500">
                          Roll: {student.roll}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button className={`px-3 py-1 rounded-md ${attendanceStatus[student.id] === 'present' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`} onClick={() => toggleAttendanceStatus(student.id)}>
                        Present
                      </button>
                      <button className={`px-3 py-1 rounded-md ${attendanceStatus[student.id] === 'absent' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`} onClick={() => toggleAttendanceStatus(student.id)}>
                        Absent
                      </button>
                    </div>
                  </div>)}
              </div>
            </div>
            <div className="p-6 border-t flex justify-end space-x-3">
              <button onClick={() => setShowMarkModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                Cancel
              </button>
              <button onClick={handleMarkAttendance} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                <CheckIcon className="w-4 h-4 mr-2" /> Save Attendance
              </button>
            </div>
          </div>
        </div>}
    </div>;
};
export default Attendance;