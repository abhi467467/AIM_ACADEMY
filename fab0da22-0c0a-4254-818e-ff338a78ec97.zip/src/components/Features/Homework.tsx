import React, { useState } from 'react';
import { FileTextIcon, CheckIcon, XIcon, PlusIcon, DownloadIcon, UploadIcon, ClockIcon, AlertCircleIcon, FileIcon, MessageSquareIcon } from 'lucide-react';
const Homework = ({
  userRole
}) => {
  const [activeTab, setActiveTab] = useState(userRole === 'teacher' ? 'assigned' : 'pending');
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [selectedHomework, setSelectedHomework] = useState(null);
  const [newAssignment, setNewAssignment] = useState({
    title: '',
    subject: '',
    description: '',
    dueDate: '',
    file: null
  });
  const [feedback, setFeedback] = useState({
    remarks: '',
    score: ''
  });
  // Mock data
  const pendingHomework = [{
    id: 1,
    title: 'Physics Problem Set',
    subject: 'Physics',
    description: 'Solve problems 1-10 from Chapter 5',
    assignedDate: '2023-08-01',
    dueDate: '2023-08-15',
    teacher: 'Dr. Smith',
    status: 'pending'
  }, {
    id: 2,
    title: 'Essay on Modern Literature',
    subject: 'English',
    description: 'Write a 500-word essay on the themes in modern literature',
    assignedDate: '2023-08-02',
    dueDate: '2023-08-18',
    teacher: 'Prof. Davis',
    status: 'pending'
  }];
  const submittedHomework = [{
    id: 3,
    title: 'Chemistry Lab Report',
    subject: 'Chemistry',
    description: 'Write a report on the acid-base titration experiment',
    assignedDate: '2023-07-25',
    dueDate: '2023-08-05',
    submittedDate: '2023-08-04',
    teacher: 'Dr. Williams',
    status: 'submitted',
    fileUrl: 'https://example.com/homework3'
  }];
  const gradedHomework = [{
    id: 4,
    title: 'Mathematics Exercises',
    subject: 'Mathematics',
    description: 'Complete exercises 15-30 from Chapter 3',
    assignedDate: '2023-07-20',
    dueDate: '2023-07-30',
    submittedDate: '2023-07-29',
    gradedDate: '2023-08-02',
    teacher: 'Prof. Johnson',
    status: 'graded',
    score: 85,
    remarks: 'Good work, but pay more attention to problems 25-27.',
    fileUrl: 'https://example.com/homework4'
  }];
  // Teacher specific data
  const assignedHomework = [{
    id: 1,
    title: 'Physics Problem Set',
    subject: 'Physics',
    description: 'Solve problems 1-10 from Chapter 5',
    assignedDate: '2023-08-01',
    dueDate: '2023-08-15',
    assignedTo: 'Class XI-A',
    submissions: 15,
    totalStudents: 30
  }, {
    id: 2,
    title: 'Essay on Modern Literature',
    subject: 'English',
    description: 'Write a 500-word essay on the themes in modern literature',
    assignedDate: '2023-08-02',
    dueDate: '2023-08-18',
    assignedTo: 'Class XI-B',
    submissions: 12,
    totalStudents: 28
  }];
  const toReviewHomework = [{
    id: 3,
    title: 'Chemistry Lab Report',
    subject: 'Chemistry',
    description: 'Write a report on the acid-base titration experiment',
    assignedDate: '2023-07-25',
    dueDate: '2023-08-05',
    assignedTo: 'Class XI-A',
    submissions: 25,
    totalStudents: 30,
    pendingReview: 10
  }];
  const studentSubmissions = [{
    id: 1,
    studentName: 'John Doe',
    studentId: 'ST001',
    submittedDate: '2023-08-04',
    fileUrl: 'https://example.com/submission1'
  }, {
    id: 2,
    studentName: 'Jane Smith',
    studentId: 'ST002',
    submittedDate: '2023-08-03',
    fileUrl: 'https://example.com/submission2'
  }, {
    id: 3,
    studentName: 'Mike Johnson',
    studentId: 'ST003',
    submittedDate: '2023-08-05',
    fileUrl: 'https://example.com/submission3'
  }];
  const handleAssignHomework = e => {
    e.preventDefault();
    // In a real app, this would send data to the backend
    console.log('Assigning homework:', newAssignment);
    setShowAssignModal(false);
    // Reset form
    setNewAssignment({
      title: '',
      subject: '',
      description: '',
      dueDate: '',
      file: null
    });
  };
  const handleSubmitFeedback = e => {
    e.preventDefault();
    // In a real app, this would send data to the backend
    console.log('Submitting feedback:', feedback, 'for student:', selectedHomework);
    setShowFeedbackModal(false);
    // Reset form
    setFeedback({
      remarks: '',
      score: ''
    });
    setSelectedHomework(null);
  };
  const openFeedbackModal = student => {
    setSelectedHomework(student);
    setShowFeedbackModal(true);
  };
  return <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Homework</h1>
        {userRole === 'teacher' && <button onClick={() => setShowAssignModal(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" /> Assign Homework
          </button>}
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="flex border-b overflow-x-auto">
          {userRole === 'student' ? <>
              <button className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${activeTab === 'pending' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('pending')}>
                Pending ({pendingHomework.length})
              </button>
              <button className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${activeTab === 'submitted' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('submitted')}>
                Submitted ({submittedHomework.length})
              </button>
              <button className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${activeTab === 'graded' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('graded')}>
                Graded ({gradedHomework.length})
              </button>
            </> : <>
              <button className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${activeTab === 'assigned' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('assigned')}>
                Assigned ({assignedHomework.length})
              </button>
              <button className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${activeTab === 'toReview' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('toReview')}>
                To Review (
                {toReviewHomework.reduce((acc, hw) => acc + hw.pendingReview, 0)}
                )
              </button>
            </>}
        </div>
        <div className="p-6">
          {userRole === 'student' ?
        // Student view
        <>
              {activeTab === 'pending' && <div className="space-y-6">
                  {pendingHomework.length > 0 ? pendingHomework.map(hw => <div key={hw.id} className="border border-gray-200 rounded-lg p-5">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                          <div>
                            <div className="flex items-center">
                              <div className="bg-yellow-100 p-2 rounded-md mr-3">
                                <FileTextIcon className="w-5 h-5 text-yellow-600" />
                              </div>
                              <div>
                                <h3 className="font-medium text-lg">
                                  {hw.title}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  {hw.subject} • Assigned by {hw.teacher}
                                </p>
                              </div>
                            </div>
                            <div className="mt-4 text-sm">
                              <p className="text-gray-700">{hw.description}</p>
                              <div className="flex items-center mt-2 text-gray-500">
                                <ClockIcon className="w-4 h-4 mr-1" />
                                <span>
                                  Due:{' '}
                                  {new Date(hw.dueDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 md:mt-0 flex flex-col space-y-2">
                            <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 flex items-center justify-center">
                              <DownloadIcon className="w-4 h-4 mr-2" /> Download
                              Assignment
                            </button>
                            <button className="border border-indigo-600 text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-50 flex items-center justify-center">
                              <UploadIcon className="w-4 h-4 mr-2" /> Submit
                              Solution
                            </button>
                          </div>
                        </div>
                      </div>) : <div className="text-center py-8">
                      <CheckIcon className="w-12 h-12 text-green-500 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900">
                        No pending homework
                      </h3>
                      <p className="text-gray-500 mt-1">
                        You're all caught up!
                      </p>
                    </div>}
                </div>}
              {activeTab === 'submitted' && <div className="space-y-6">
                  {submittedHomework.length > 0 ? submittedHomework.map(hw => <div key={hw.id} className="border border-gray-200 rounded-lg p-5">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                          <div>
                            <div className="flex items-center">
                              <div className="bg-blue-100 p-2 rounded-md mr-3">
                                <FileTextIcon className="w-5 h-5 text-blue-600" />
                              </div>
                              <div>
                                <h3 className="font-medium text-lg">
                                  {hw.title}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  {hw.subject} • Assigned by {hw.teacher}
                                </p>
                              </div>
                            </div>
                            <div className="mt-4 text-sm">
                              <p className="text-gray-700">{hw.description}</p>
                              <div className="flex items-center mt-2 text-gray-500">
                                <ClockIcon className="w-4 h-4 mr-1" />
                                <span>
                                  Submitted:{' '}
                                  {new Date(hw.submittedDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 md:mt-0 flex flex-col space-y-2">
                            <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-md flex items-center justify-center">
                              <CheckIcon className="w-4 h-4 mr-2" /> Submitted
                            </div>
                            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 flex items-center justify-center">
                              <FileIcon className="w-4 h-4 mr-2" /> View
                              Submission
                            </button>
                          </div>
                        </div>
                      </div>) : <div className="text-center py-8">
                      <UploadIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900">
                        No submitted homework
                      </h3>
                      <p className="text-gray-500 mt-1">
                        You haven't submitted any homework yet.
                      </p>
                    </div>}
                </div>}
              {activeTab === 'graded' && <div className="space-y-6">
                  {gradedHomework.length > 0 ? gradedHomework.map(hw => <div key={hw.id} className="border border-gray-200 rounded-lg p-5">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                          <div>
                            <div className="flex items-center">
                              <div className="bg-green-100 p-2 rounded-md mr-3">
                                <FileTextIcon className="w-5 h-5 text-green-600" />
                              </div>
                              <div>
                                <h3 className="font-medium text-lg">
                                  {hw.title}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  {hw.subject} • Graded by {hw.teacher}
                                </p>
                              </div>
                            </div>
                            <div className="mt-4 text-sm">
                              <p className="text-gray-700">{hw.description}</p>
                              <div className="flex items-center mt-2 text-gray-500">
                                <ClockIcon className="w-4 h-4 mr-1" />
                                <span>
                                  Graded on:{' '}
                                  {new Date(hw.gradedDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                                </span>
                              </div>
                              <div className="mt-4 p-3 bg-gray-50 rounded-md">
                                <div className="font-medium">
                                  Score: {hw.score}/100
                                </div>
                                <div className="mt-1">
                                  Remarks: {hw.remarks}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 md:mt-0 flex flex-col space-y-2">
                            <div className="bg-green-100 text-green-800 px-4 py-2 rounded-md flex items-center justify-center">
                              <CheckIcon className="w-4 h-4 mr-2" /> Score:{' '}
                              {hw.score}/100
                            </div>
                            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 flex items-center justify-center">
                              <FileIcon className="w-4 h-4 mr-2" /> View
                              Submission
                            </button>
                          </div>
                        </div>
                      </div>) : <div className="text-center py-8">
                      <AlertCircleIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900">
                        No graded homework
                      </h3>
                      <p className="text-gray-500 mt-1">
                        Your submissions haven't been graded yet.
                      </p>
                    </div>}
                </div>}
            </> :
        // Teacher view
        <>
              {activeTab === 'assigned' && <div className="space-y-6">
                  {assignedHomework.length > 0 ? assignedHomework.map(hw => <div key={hw.id} className="border border-gray-200 rounded-lg p-5">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                          <div>
                            <div className="flex items-center">
                              <div className="bg-indigo-100 p-2 rounded-md mr-3">
                                <FileTextIcon className="w-5 h-5 text-indigo-600" />
                              </div>
                              <div>
                                <h3 className="font-medium text-lg">
                                  {hw.title}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  {hw.subject} • {hw.assignedTo}
                                </p>
                              </div>
                            </div>
                            <div className="mt-4 text-sm">
                              <p className="text-gray-700">{hw.description}</p>
                              <div className="flex items-center mt-2 text-gray-500">
                                <ClockIcon className="w-4 h-4 mr-1" />
                                <span>
                                  Due:{' '}
                                  {new Date(hw.dueDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 md:mt-0 flex flex-col space-y-2">
                            <div className="bg-indigo-100 text-indigo-800 px-4 py-2 rounded-md flex items-center justify-center">
                              <CheckIcon className="w-4 h-4 mr-2" />{' '}
                              {hw.submissions}/{hw.totalStudents} Submissions
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                              <div className="bg-indigo-600 h-2 rounded-full" style={{
                      width: `${hw.submissions / hw.totalStudents * 100}%`
                    }}></div>
                            </div>
                            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 flex items-center justify-center mt-2">
                              <FileIcon className="w-4 h-4 mr-2" /> View
                              Assignment
                            </button>
                          </div>
                        </div>
                      </div>) : <div className="text-center py-8">
                      <FileTextIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900">
                        No assigned homework
                      </h3>
                      <p className="text-gray-500 mt-1">
                        You haven't assigned any homework yet.
                      </p>
                    </div>}
                </div>}
              {activeTab === 'toReview' && <div className="space-y-6">
                  {toReviewHomework.length > 0 ? <>
                      {toReviewHomework.map(hw => <div key={hw.id} className="border border-gray-200 rounded-lg p-5">
                          <div className="mb-4">
                            <div className="flex items-center">
                              <div className="bg-orange-100 p-2 rounded-md mr-3">
                                <FileTextIcon className="w-5 h-5 text-orange-600" />
                              </div>
                              <div>
                                <h3 className="font-medium text-lg">
                                  {hw.title}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  {hw.subject} • {hw.assignedTo}
                                </p>
                              </div>
                            </div>
                            <div className="mt-2 text-sm">
                              <p className="text-gray-700">{hw.description}</p>
                              <div className="flex items-center mt-2 text-gray-500">
                                <ClockIcon className="w-4 h-4 mr-1" />
                                <span>
                                  Due:{' '}
                                  {new Date(hw.dueDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                                </span>
                              </div>
                            </div>
                            <div className="mt-4 bg-orange-50 text-orange-800 px-4 py-2 rounded-md inline-flex items-center">
                              <AlertCircleIcon className="w-4 h-4 mr-2" />{' '}
                              {hw.pendingReview} submissions pending review
                            </div>
                          </div>
                          <div className="border-t pt-4">
                            <h4 className="font-medium mb-3">
                              Student Submissions
                            </h4>
                            <div className="overflow-x-auto">
                              <table className="min-w-full divide-y divide-gray-200">
                                <thead>
                                  <tr>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                      Student
                                    </th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                      Submitted Date
                                    </th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                      Actions
                                    </th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                  {studentSubmissions.map(student => <tr key={student.id}>
                                      <td className="px-4 py-3 whitespace-nowrap">
                                        <div className="font-medium">
                                          {student.studentName}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                          ID: {student.studentId}
                                        </div>
                                      </td>
                                      <td className="px-4 py-3 whitespace-nowrap">
                                        {new Date(student.submittedDate).toLocaleDateString()}
                                      </td>
                                      <td className="px-4 py-3 whitespace-nowrap">
                                        <div className="flex space-x-2">
                                          <button className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 text-sm" onClick={() => window.open(student.fileUrl, '_blank')}>
                                            View
                                          </button>
                                          <button className="px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 text-sm" onClick={() => openFeedbackModal(student)}>
                                            Grade
                                          </button>
                                        </div>
                                      </td>
                                    </tr>)}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>)}
                    </> : <div className="text-center py-8">
                      <CheckIcon className="w-12 h-12 text-green-500 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900">
                        No pending reviews
                      </h3>
                      <p className="text-gray-500 mt-1">
                        You're all caught up!
                      </p>
                    </div>}
                </div>}
            </>}
        </div>
      </div>
      {/* Assign Homework Modal */}
      {showAssignModal && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">Assign New Homework</h3>
              <button onClick={() => setShowAssignModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAssignHomework} className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input type="text" required value={newAssignment.title} onChange={e => setNewAssignment({
              ...newAssignment,
              title: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Physics Problem Set" />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <select required value={newAssignment.subject} onChange={e => setNewAssignment({
              ...newAssignment,
              subject: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">Select a subject</option>
                  <option value="Physics">Physics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Biology">Biology</option>
                  <option value="English">English</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea required value={newAssignment.description} onChange={e => setNewAssignment({
              ...newAssignment,
              description: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" rows={3} placeholder="Describe the homework assignment..."></textarea>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date
                </label>
                <input type="date" required value={newAssignment.dueDate} onChange={e => setNewAssignment({
              ...newAssignment,
              dueDate: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upload File (Optional)
                </label>
                <div className="border border-gray-300 rounded-md p-4">
                  <input type="file" onChange={e => setNewAssignment({
                ...newAssignment,
                file: e.target.files[0]
              })} className="w-full" />
                </div>
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowAssignModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Assign Homework
                </button>
              </div>
            </form>
          </div>
        </div>}
      {/* Feedback Modal */}
      {showFeedbackModal && selectedHomework && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-bold">Provide Feedback</h3>
              <button onClick={() => setShowFeedbackModal(false)} className="text-gray-400 hover:text-gray-600">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 border-b">
              <div className="font-medium">{selectedHomework.studentName}</div>
              <div className="text-sm text-gray-500">
                ID: {selectedHomework.studentId}
              </div>
              <div className="text-sm text-gray-500 mt-1">
                Submitted:{' '}
                {new Date(selectedHomework.submittedDate).toLocaleDateString()}
              </div>
              <div className="mt-3">
                <button className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 text-sm flex items-center" onClick={() => window.open(selectedHomework.fileUrl, '_blank')}>
                  <FileIcon className="w-4 h-4 mr-1" /> View Submission
                </button>
              </div>
            </div>
            <form onSubmit={handleSubmitFeedback} className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Score (0-100)
                </label>
                <input type="number" required min="0" max="100" value={feedback.score} onChange={e => setFeedback({
              ...feedback,
              score: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Remarks
                </label>
                <textarea required value={feedback.remarks} onChange={e => setFeedback({
              ...feedback,
              remarks: e.target.value
            })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" rows={4} placeholder="Provide feedback on the student's work..."></textarea>
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowFeedbackModal(false)} className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center">
                  <CheckIcon className="w-4 h-4 mr-2" /> Submit Feedback
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default Homework;