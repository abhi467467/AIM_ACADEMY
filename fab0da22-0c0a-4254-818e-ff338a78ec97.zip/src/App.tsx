import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/Auth/LoginPage';
import DashboardLayout from './components/Layout/DashboardLayout';
import LiveLectures from './components/Features/LiveLectures';
import StudyMaterials from './components/Features/StudyMaterials';
import Homework from './components/Features/Homework';
import Notices from './components/Features/Notices';
import Attendance from './components/Features/Attendance';
import TestResults from './components/Features/TestResults';
import StudentDashboard from './components/Dashboard/StudentDashboard';
import TeacherDashboard from './components/Dashboard/TeacherDashboard';
export function App() {
  const [user, setUser] = useState(null);
  const handleLogin = userData => {
    setUser(userData);
  };
  const handleLogout = () => {
    setUser(null);
  };
  return <Router>
      <Routes>
        <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
        {user ? <Route path="/" element={<DashboardLayout user={user} onLogout={handleLogout} />}>
            <Route index element={user.role === 'teacher' ? <TeacherDashboard /> : <StudentDashboard />} />
            <Route path="live-lectures" element={<LiveLectures userRole={user.role} />} />
            <Route path="study-materials" element={<StudyMaterials userRole={user.role} />} />
            <Route path="homework" element={<Homework userRole={user.role} />} />
            <Route path="notices" element={<Notices userRole={user.role} />} />
            <Route path="attendance" element={<Attendance userRole={user.role} />} />
            <Route path="test-results" element={<TestResults userRole={user.role} />} />
          </Route> : <Route path="*" element={<Navigate to="/login" replace />} />}
      </Routes>
    </Router>;
}